package com.example.myapplication;



import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Random;

public class Radon extends AppCompatActivity {
    private Button btn_guess;
    private EditText edit_number;
    private  int rnd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radon);

        Random mRandom = new Random();

        rnd = mRandom.nextInt(100)+1;
        btn_guess=(Button)findViewById(R.id.btn_guess);
        edit_number=(EditText)findViewById(R.id.edit_number);
        btn_guess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str=edit_number.getText().toString();
                if(str.isEmpty())
                    Toast.makeText(Radon.this, R.string.toast_equal,
                            Toast.LENGTH_SHORT).show();
                else
                {
                    int num =Integer.parseInt(str);
                    if(num>rnd)
                        Toast.makeText(Radon.this,R.string.toast_big,
                                Toast.LENGTH_SHORT).show();
                    else  if(num<rnd)
                        Toast.makeText(Radon.this,R.string.toast_small,
                                Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(Radon.this,R.string.toast_equal,
                                Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}