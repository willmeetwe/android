package com.example.myapplication;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;


public class Counting extends AppCompatActivity {
    CheckBox stu1, stu2, stu3, stu4, stu5, stu6, stu7, stu8, stu9, stu10,stu11,stu12;
    CheckBox stu13,stu14,stu15,stu16,stu17,stu18,stu19,stu20,stu21,stu22,stu23,stu24;

    EditText et_name;
    Button btn_submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counting);

        //第二部分
        et_name=(EditText) findViewById(R.id.et_name);
        btn_submit=(Button) findViewById(R.id.btn_submit);
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=et_name.getText().toString();
                Intent i=new Intent();
                i.setClass(Counting.this,Counting2.class);

                Bundle b=new Bundle();
                b.putString("n",name);
                i.putExtras(b);
                //startActivity(i);
                startActivityForResult(i,1);
            }
        });

        //第一部分
        stu1=(CheckBox) findViewById(R.id.stu1);
        stu2=(CheckBox) findViewById(R.id.stu2);
        stu3=(CheckBox) findViewById(R.id.stu3);
        stu4=(CheckBox) findViewById(R.id.stu4);

        stu5=(CheckBox) findViewById(R.id.stu5);
        stu6=(CheckBox) findViewById(R.id.stu6);
        stu7=(CheckBox) findViewById(R.id.stu7);
        stu8=(CheckBox) findViewById(R.id.stu8);

        stu9=(CheckBox) findViewById(R.id.stu9);
        stu10=(CheckBox) findViewById(R.id.stu10);
        stu11=(CheckBox) findViewById(R.id.stu11);
        stu12=(CheckBox) findViewById(R.id.stu12);

        stu13=(CheckBox) findViewById(R.id.stu13);
        stu14=(CheckBox) findViewById(R.id.stu14);
        stu15=(CheckBox) findViewById(R.id.stu15);
        stu16=(CheckBox) findViewById(R.id.stu16);

        stu17=(CheckBox) findViewById(R.id.stu17);
        stu18=(CheckBox) findViewById(R.id.stu18);
        stu19=(CheckBox) findViewById(R.id.stu19);
        stu20=(CheckBox) findViewById(R.id.stu20);

        stu21=(CheckBox) findViewById(R.id.stu21);
        stu22=(CheckBox) findViewById(R.id.stu22);
        stu23=(CheckBox) findViewById(R.id.stu23);
        stu24=(CheckBox) findViewById(R.id.stu24);
        btn_submit=(Button) findViewById(R.id.btn_submit);

        btn_submit.setOnClickListener( new ButtonOnClickListener());
    }
    //     , , , stu7, stu8, stu9, stu10,stu11,stu12;
    // stu13,stu14,stu15,stu16,stu17,stu18,stu19,stu20,stu21,stu22,stu23,stu24;
    private  class ButtonOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            String stu = "";
            if (stu1.isChecked())
                stu = stu + stu1.getText().toString();
            if(stu2.isChecked())
                stu = stu +stu2.getText().toString();
            if(stu3.isChecked())
                stu = stu +stu3.getText().toString();
            if(stu4.isChecked())
                stu = stu  +stu4.getText().toString();
            if(stu5.isChecked())
                stu = stu  +stu5.getText().toString();
            if(stu6.isChecked())
                stu = stu  +stu6.getText().toString();

            if (stu7.isChecked())
                stu = stu + stu7.getText().toString();
            if(stu8.isChecked())
                stu = stu +stu8.getText().toString();
            if(stu1.isChecked())
                stu = stu +stu9.getText().toString();
            if(stu10.isChecked())
                stu = stu  +stu10.getText().toString();
            if(stu11.isChecked())
                stu = stu  +stu11.getText().toString();
            if(stu12.isChecked())
                stu = stu  +stu12.getText().toString();

            if (stu13.isChecked())
                stu = stu + stu13.getText().toString();
            if(stu14.isChecked())
                stu = stu +stu14.getText().toString();
            if(stu15.isChecked())
                stu = stu +stu15.getText().toString();
            if(stu16.isChecked())
                stu = stu  +stu16.getText().toString();
            if(stu17.isChecked())
                stu = stu  +stu17.getText().toString();
            if(stu18.isChecked())
                stu = stu  +stu18.getText().toString();

            if (stu19.isChecked())
                stu = stu + stu19.getText().toString();
            if(stu20.isChecked())
                stu = stu +stu20.getText().toString();
            if(stu21.isChecked())
                stu = stu +stu21.getText().toString();
            if(stu22.isChecked())
                stu = stu  +stu22.getText().toString();
            if(stu23.isChecked())
                stu = stu  +stu23.getText().toString();
            if(stu24.isChecked())
                stu = stu  +stu24.getText().toString();
            if(stu.isEmpty())
                stu  = "无";
            /*Toast.makeText(MainActivity.this, name+"提交的信息是：\n地址:"+provice+city+"爱好："+hobby,
                    Toast.LENGTH_SHORT).show();*/
            Intent intent = new Intent(Counting.this,Counting2.class);
            intent.putExtra("stu",stu);
            Counting.this.startActivity(intent);
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {


        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:
                Bundle returnBundle = data.getExtras();
                String result = returnBundle.getString("r");
                et_name.setText(result);

        }
        switch (resultCode) {
            case 2:
                Bundle returnBundle = data.getExtras();
                String result = returnBundle.getString("r");
                et_name.setText(result);

        }
    }
}
