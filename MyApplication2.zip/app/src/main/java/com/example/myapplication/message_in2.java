package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class message_in2 extends AppCompatActivity {
    TextView txt_name;
    TextView txt_address;
    TextView txt_hobby;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_in2);

        intent =getIntent();
        String name=intent.getStringExtra("name");
        String address= intent.getStringExtra("address");
        String hobby = intent.getStringExtra("hobby");

        txt_name = (TextView) findViewById(R.id.txt_name);
        txt_address=(TextView) findViewById(R.id.txt_address);
        txt_hobby=(TextView) findViewById(R.id.txt_hobby);
        txt_name.setText(name);
        txt_address.setText(address);
        txt_hobby.setText(hobby);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_submit,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item_back:
                message_in2.this.finish();
                break;
            case R.id.item_exit:
                break;
        }
        return  true;
    }
}