package com.example.myapplication;



import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Counting2 extends AppCompatActivity {

    TextView student;
    Intent intent;



    TextView tv_info;
    Button bt_return;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counting2);
        //3

        //第二部分
        Intent i=this.getIntent();
        Bundle b=i.getExtras();
        String data=b.getString("n");


        tv_info=(TextView) findViewById(R.id.tv_message);
        tv_info.setText(data);
        bt_return=(Button) findViewById(R.id.bt_return);
        bt_return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result="";
                Intent returndate=new Intent();
                Bundle b2=new Bundle();
                b2.putString("result",result);
                returndate.putExtras(b2);

                setResult(2,returndate);
                finish();
            }
        });

//第一部分
        intent =getIntent();
        String students = intent.getStringExtra("stu");
        student=(TextView) findViewById(R.id.tv_message);
        student.setText(students);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item_back:
                Counting2.this.finish();
                break;
            case R.id.item_exit:
                break;
        }
        return  true;
    }
    //3


    //2
    @Override
    public void onBackPressed() {

        String result="这是第二个Actity的数据处理结果";
        Intent returndate=new Intent();
        Bundle b2=new Bundle();
        b2.putString("result",result);
        returndate.putExtras(b2);

        setResult(2,returndate);
        finish();
    }
}