package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=findViewById(R.id.btn);
        button.setOnClickListener(new MyClick());
        button=findViewById(R.id.btn1);
        button.setOnClickListener(new MyClick1());
        button=findViewById(R.id.btn2);
        button.setOnClickListener(new MyClick2());
        button=findViewById(R.id.btn3);
        button.setOnClickListener(new MyClick3());
        button=findViewById(R.id.btn4);
        button.setOnClickListener(new MyClick4());
        button=findViewById(R.id.btn5);
        button.setOnClickListener(new MyClick5());
        button=findViewById(R.id.btn6);
        button.setOnClickListener(new MyClick6());
        button=findViewById(R.id.btn7);
        button.setOnClickListener(new MyClick7());
        button=findViewById(R.id.btn8);
        button.setOnClickListener(new MyClick8());

    }
    public class MyClick implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MainActivity.this, Radon.class);
            Toast.makeText(MainActivity.this, "请猜出1-100以内的一个数", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
    public class MyClick1 implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MainActivity.this, message_in.class);
            Toast.makeText(MainActivity.this, "个人信息提交", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
    public class MyClick2 implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MainActivity.this, studentlist.class);
            Toast.makeText(MainActivity.this, "班级成员", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
    public class MyClick3 implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MainActivity.this, login.class);
            Toast.makeText(MainActivity.this, "登录界面", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
    public class MyClick4 implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MainActivity.this, Foods.class);
            Toast.makeText(MainActivity.this, "校园美食", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
    public class MyClick5 implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MainActivity.this, BMI_kgm.class);
            Toast.makeText(MainActivity.this, "BMI_身体质量指数", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
    public class MyClick6 implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MainActivity.this, Calculator.class);
            Toast.makeText(MainActivity.this, "打开计算器", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
    public class MyClick7 implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MainActivity.this, Counting.class);
            Toast.makeText(MainActivity.this, "人员名单统计", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
    public class MyClick8 implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(MainActivity.this, Tab.class);
            Toast.makeText(MainActivity.this, "收藏室已到达", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }
}