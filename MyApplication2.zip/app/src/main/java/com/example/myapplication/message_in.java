package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class message_in extends AppCompatActivity {
    EditText edit_name;
    Spinner spn_provice;
    Spinner spn_city;
    CheckBox chb_sing;
    CheckBox chb_code;
    CheckBox chb_write;
    CheckBox chb_dance;
    Button btn_submit;
    String [][] arrCity = new String[][]{
            {"请选择市"},{"请选择市","济南","青岛","泰安","日照"},
            {"请选择市","南京","苏州","无锡","盐城"},
            {"请选择市","合肥","芜湖","蚌埠","铜陵"},
            {"请选择市","杭州","温州","绍兴","嘉兴"}
    };

    ArrayAdapter<String >adapterCity=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_in);

        edit_name=(EditText) findViewById(R.id.editText);
        spn_provice=(Spinner) findViewById(R.id.spn_provice);
        spn_city=(Spinner) findViewById(R.id.spn_city);
        chb_sing=(CheckBox) findViewById(R.id.chb_sing);
        chb_code=(CheckBox) findViewById(R.id.chb_code);
        chb_write=(CheckBox) findViewById(R.id.chb_write);
        chb_dance=(CheckBox) findViewById(R.id.chb_dance);
        btn_submit=(Button) findViewById(R.id.btn_submit);

        spn_provice.setOnItemSelectedListener(new SpinnerOnItemSelectedListener());
        btn_submit.setOnClickListener( new ButtonOnClickListener());

    }



    private class SpinnerOnItemSelectedListener implements AdapterView.OnItemSelectedListener{
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            switch (parent.getId()){
                case R.id.spn_provice:
                    adapterCity=new ArrayAdapter<String>(message_in.this, android.R.layout.
                            simple_spinner_item,arrCity[position]);
                    adapterCity.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spn_city.setAdapter(adapterCity);
                    break;
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }
    private  class ButtonOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            String name = edit_name.getText().toString();
            if (name.isEmpty()) {
                Toast.makeText(message_in.this, "请输入姓名", Toast.LENGTH_SHORT).show();
                return;
            }
            if (spn_provice.getSelectedItemPosition() <= 0 || spn_provice.getSelectedItemPosition() > 4) {
                Toast.makeText(message_in.this, "请选择省", Toast.LENGTH_SHORT).show();
                return;
            }
            if (spn_city.getSelectedItemPosition() <= 0 || spn_provice.getSelectedItemPosition() > 4) {
                Toast.makeText(message_in.this, "请选择市", Toast.LENGTH_SHORT).show();
                return;
            }
            //System.out.println(spn_provice.getSelectedItemId());
            String provice = String.valueOf(spn_provice.getSelectedItem().toString());
            String city = String.valueOf(spn_city.getSelectedItem().toString());
            String hobby = "";
            if (chb_sing.isChecked())
                hobby = hobby + chb_sing.getText().toString();
            if(chb_code.isChecked())
                hobby = hobby +chb_code.getText().toString();
            if(chb_write.isChecked())
                hobby = hobby +chb_write.getText().toString();
            if(chb_dance.isChecked())
                hobby = hobby  +chb_dance.getText().toString();
            if(hobby.isEmpty())
                hobby  = "无";
            /*Toast.makeText(MainActivity.this, name+"提交的信息是：\n地址:"+provice+city+"爱好："+hobby,
                    Toast.LENGTH_SHORT).show();*/
            Intent intent = new Intent(message_in.this,message_in2.class);
            intent.putExtra("name",name);
            intent.putExtra("address",provice+city);
            intent.putExtra("hobby",hobby);
            message_in.this.startActivity(intent);
        }
    }

}