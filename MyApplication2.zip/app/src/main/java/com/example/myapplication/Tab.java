package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tab extends AppCompatActivity {
    private Button firstBt;
    private Button secondBt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab);
        firstBt=(Button) findViewById(R.id.firstBt);
        secondBt=(Button) findViewById(R.id.secondBt);
        firstBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(Tab.this,Tab2.class);
                startActivity(intent);
            }
        });
        secondBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent();
                intent.setClass(Tab.this,Tab3.class);
                startActivity(intent);
            }
        });
    }
}