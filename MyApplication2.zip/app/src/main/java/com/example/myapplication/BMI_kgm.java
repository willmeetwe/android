package com.example.myapplication;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

public class BMI_kgm extends AppCompatActivity {

    EditText one, two;
    Button btn_1;
    RadioButton man,woman;
    TextView computer;
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_kgm);

        button=findViewById(R.id.btn);
        button.setOnClickListener(new MyClick());

        one= (EditText) findViewById(R.id.height);
        two= (EditText) findViewById(R.id.weight);
        computer=(TextView) findViewById(R.id.computer);
        man=(RadioButton) findViewById(R.id.man);
        woman=(RadioButton) findViewById(R.id.woman);
        btn_1 = (Button) findViewById(R.id.btn_1);
        btn_1.setOnClickListener(this::onClick);
    }
    public class MyClick implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Intent intent  = new Intent(BMI_kgm.this, MainActivity.class);
            startActivity(intent);
        }
    }

    public void onClick(View v){
        double o=Double.parseDouble(one.getText().toString());
        double t=Double.parseDouble(two.getText().toString());
        double res;

        if(o<=0 || t<=0) {
            computer.setText("值异常，不计算");
            return ;
        }
        o =o/100;
        res = t / (o*o);
        @SuppressLint("DefaultLocale") String str1 = String.format("%.2f",res);
        if(man.isChecked()) {
            if (res < 19)
                Toast.makeText(BMI_kgm.this, "先生：体重偏低，偏瘦", Toast.LENGTH_SHORT).show();
            else if (res < 25)
                Toast.makeText(BMI_kgm.this, "先生：健康体重,身材正常", Toast.LENGTH_SHORT).show();
            else if (res < 30)
                Toast.makeText(BMI_kgm.this, "先生：超重,偏胖", Toast.LENGTH_SHORT).show();
            else if (res < 39)
                Toast.makeText(BMI_kgm.this, "先生：严重超重,肥胖", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(BMI_kgm.this, "先生：极度超重,属于严重肥胖", Toast.LENGTH_SHORT).show();
        }
        if(woman.isChecked()) {

            if (res < 19)
                Toast.makeText(BMI_kgm.this, "女士：体重偏低，偏瘦", Toast.LENGTH_SHORT).show();
            else if (res < 25)
                Toast.makeText(BMI_kgm.this, "女士：健康体重,身材正常", Toast.LENGTH_SHORT).show();
            else if (res < 30)
                Toast.makeText(BMI_kgm.this, "女士：超重,偏胖", Toast.LENGTH_SHORT).show();
            else if (res < 39)
                Toast.makeText(BMI_kgm.this, "女士：严重超重,肥胖", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(BMI_kgm.this, "女士：极度超重,属于严重肥胖", Toast.LENGTH_SHORT).show();
        }
    }
}

