package com.example.myapplication;


import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Foods extends AppCompatActivity {
    ListView list_food;
    int[] img_food = {R.drawable.food_1, R.drawable.food_2, R.drawable.food_3,
            R.drawable.food_4, R.drawable.food_2,};
    String[] food_name = {"五谷鱼粉", "烟熏鸡茶泡饭", "川味人家锅仔", "初味柠檬鱼", "韩式铁板饭"};
    int[] food_price = {12, 10, 25, 13, 13};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foods);

//菜单
        list_food = (ListView) findViewById(R.id.list_food);

        List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();

        for (int i = 0; i < 5; i++) {
            Map<String, Object> m = new HashMap<String, Object>();

            m.put("food_image", img_food[i]);
            m.put("food_name", food_name[i]);
            m.put("food_price", food_price[i]);

            data.add(m);

        }
        SimpleAdapter ada = new SimpleAdapter(Foods.this, data,
                R.layout.activity_foods2,
                new String[]{"food_image", "food_name", "food_price"},
                new int[]{R.id.img_food, R.id.tv_foodname, R.id.tv_foodprice});
        list_food.setAdapter(ada);

        list_food.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String info = "食品名称：" + food_name[position] + "，价格：" + food_price[position];
                Toast.makeText(Foods.this, info, Toast.LENGTH_SHORT).show();
            }
        });

        //       从布局文件中获取名叫roll_button的按钮对象的引用
        Button rollButton = findViewById(R.id.roll_button);
//        在代码中修改按钮rollButton文本属性
        rollButton.setText("今天吃什么呢？请点击");

//        给按钮rollButton设置点击监听器，一旦用户点击按钮，就触发监听器的onClick方法
        rollButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

//                产生随机数
                Random rand = new Random();
                int randNumber = rand.nextInt(6)+1;
//                String randNumber2 = rand.nextInt(6)+1;

//                获取对ImageView对象的引用
                ImageView diceImage = findViewById(R.id.dice_image);

                int drawableResource;
//                将随机数与对应的图片资源联系起来
                switch (randNumber){
                    case 1: drawableResource = R.drawable.dice_1; break;
                    case 2: drawableResource = R.drawable.dice_2; break;
                    case 3: drawableResource = R.drawable.dice_3; break;
                    case 4: drawableResource = R.drawable.dice_4; break;
                    case 5: drawableResource = R.drawable.dice_5; break;
                    case 6: drawableResource = R.drawable.dice_6; break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + randNumber);
                }

//                随机图片根据rangNumber的值对应drawableResource的int值，实例Drawable类
                Drawable drawable = getBaseContext().getResources().getDrawable(drawableResource);

//                设置ImageView控件最终显示的图片
                diceImage.setImageDrawable(drawable);
            }
        });
    }
}