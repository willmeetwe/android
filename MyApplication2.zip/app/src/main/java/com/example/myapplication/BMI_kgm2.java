package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BMI_kgm2 extends AppCompatActivity {

    EditText one, two;
    Button btn_1;
    RadioButton man, woman;
    TextView computer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_kgm2);

        one = (EditText) findViewById(R.id.height);
        two = (EditText) findViewById(R.id.weight);
        computer = (TextView) findViewById(R.id.computer);
        man = (RadioButton) findViewById(R.id.man);
        woman = (RadioButton) findViewById(R.id.woman);
        btn_1 = (Button) findViewById(R.id.btn_1);
        btn_1.setOnClickListener(this::onClick1);
    }

    public void onClick1(View v) {
        String str1 = one.getText().toString();
        String str2 = two.getText().toString();
        if (str1.isEmpty())
            Toast.makeText(BMI_kgm2.this, "请输入", Toast.LENGTH_SHORT).show();
        else {
            int cm = Integer.parseInt(str1);
            int kg = Integer.parseInt(str2);
            if (kg / (cm * cm) < 19)
                Toast.makeText(BMI_kgm2.this, "体重偏低，偏瘦", Toast.LENGTH_SHORT).show();
            else if (kg / (cm * cm) < 25)
                Toast.makeText(BMI_kgm2.this, "健康体重,身材正常", Toast.LENGTH_SHORT).show();
            else if (kg / (cm * cm) < 30)
                Toast.makeText(BMI_kgm2.this, "超重,偏胖", Toast.LENGTH_SHORT).show();
            else if (kg / (cm * cm) < 39)
                Toast.makeText(BMI_kgm2.this, "严重超重,肥胖", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(BMI_kgm2.this, "极度超重,属于严重肥胖", Toast.LENGTH_SHORT).show();
        }
    }
}