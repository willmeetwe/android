package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class studentlist extends AppCompatActivity {
    GridView gird_car;
    TextView tv_info;
    int[] carlogo={R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,
            R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,
            R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher,
            R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher};
    String[] carnames={"成员一","成员二","成员三","成员四","成员五","成员六",
            "成员七","成员八","成员九","成员十","十一","十二"};
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentlist);

        button=findViewById(R.id.btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(studentlist.this)
                        .setTitle("删除")
                        .setMessage("确认删除吗")
                        .setIcon(R.mipmap.ic_launcher)
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(studentlist.this, "内容已删除", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(studentlist.this, "取消删除", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .create();
                alertDialog.show();
            }
        });

        gird_car=(GridView)findViewById(R.id.gird_card);
        tv_info=(TextView) findViewById(R.id.message);

        List<Map<String,Object>> dataList=new ArrayList<Map<String,Object>>();

        for (int i=0;i<carlogo.length;i++)
        {
            Map<String,Object> item=new HashMap<String,Object>();

            item.put("carlogo",carlogo[i]);
            item.put("name",carnames[i]);

            dataList.add(item);
        }

        SimpleAdapter ada=new SimpleAdapter(this,dataList,R.layout.activity_studentlist2,
                new String[]{"carlogo","name"},
                new int[]{R.id.img_car,R.id.tv_carname});

        gird_car.setAdapter(ada);
    }
}