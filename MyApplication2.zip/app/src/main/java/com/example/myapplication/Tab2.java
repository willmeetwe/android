package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;

import android.app.TabActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.TabHost;

public class Tab2 extends TabActivity {
    private TabHost myTabHost;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TabHost myTabHost = this.getTabHost();

        LayoutInflater.from(this).inflate(R.layout.activity_tab2,
                myTabHost.getTabContentView(),true);
        myTabHost.addTab(myTabHost
                .newTabSpec("选项卡1")
                .setIndicator("图一",getResources().getDrawable(R.drawable.ic_launcher_background))
                .setContent(R.id.firstTab));
        myTabHost.addTab(myTabHost
                .newTabSpec("选项卡2")
                .setIndicator("图二",getResources().getDrawable(R.drawable.ic_launcher_background))
                .setContent(R.id.secondTab));
        myTabHost.addTab(myTabHost
                .newTabSpec("选项卡3")
                .setIndicator("图三",getResources().getDrawable(R.drawable.ic_launcher_background))
                .setContent(R.id.thirdTab));
    }




}