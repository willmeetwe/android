package com.example.myapplication;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TabHost;

public class Tab3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab3);
        TabHost tabHost=(TabHost) findViewById(R.id.tabhost);
        tabHost.setup();
        tabHost.addTab(tabHost
                .newTabSpec("tab1")
                .setIndicator("图一",getResources().getDrawable(R.drawable.ic_launcher_background))
                .setContent(R.id.view1));
        tabHost.addTab(tabHost
                .newTabSpec("tab2")
                .setIndicator("图二",getResources().getDrawable(R.drawable.ic_launcher_background))
                .setContent(R.id.view2));
        tabHost.addTab(tabHost
                .newTabSpec("tab3")
                .setIndicator("图三",getResources().getDrawable(R.drawable.ic_launcher_background))
                .setContent(R.id.view3));
    }
}